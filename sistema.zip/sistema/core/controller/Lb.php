<?php



// Lb.php
// el objeto librari b

class Lb {

	public function Lb(){
	}

	public function start(){
		include "core/app/autoload.php";
		include "core/app/init.php";
	}

}

?>