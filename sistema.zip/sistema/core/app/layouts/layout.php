<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>TITULO AQUI</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <link href="librerias/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <!-- Font Awesome Icons -->
    <link href="librerias/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <!-- Theme style -->
    <link href="librerias/dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />
    <link href="librerias/dist/css/skins/skin-green-light.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="librerias/datatables/dataTables.bootstrap.css">
    <script src="librerias/tinymce/tinymce.min.js"></script>
    
          <script src="librerias/jquery/jquery-2.1.4.min.js"></script>
         

  </head>

  <body class="<?php if(isset($_SESSION["user_id"])):?>  skin-green-light sidebar-mini <?php else:?>login-page<?php endif; ?>" >
    <div class="wrapper">
      <!-- Main Header -->
      <?php if(isset($_SESSION["user_id"])):?>
      <header class="main-header">
        <!-- Logo -->
        <a href="./" class="logo">
          <!-- mini logo for sidebar mini 50x50 pixels -->
          <span class="logo-mini"><b>UCB</b></span>
          <!-- logo for regular state and mobile devices -->
          <span class="logo-lg"><b>UCB</b></span>
        </a>

        <!-- Header Navbar -->
        <nav class="navbar navbar-static-top" role="navigation">
          <!-- Sidebar toggle button-->
          <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
            <span class="sr-only">Toggle navigation</span>
          </a>
          <!-- Navbar Right Menu -->
          <div class="navbar-custom-menu">
            <ul class="nav navbar-nav">

              <!-- User Account Menu -->
              <li class="dropdown user user-menu">
                <!-- Menu Toggle Button -->
                <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                  <!-- The user image in the navbar-->
                  <!-- hidden-xs hides the username on small devices so only the image appears. -->
                  <span class=""><?php if(isset($_SESSION["user_id"]) ){ echo UserData::getById($_SESSION["user_id"])->name; 
                  }?> <b class="caret"></b> </span>

                </a>
                <a href="./?view=processlogout" class="btn btn-default btn-flat">Salir</a>
                <ul class="dropdown-menu">
                  <!-- The user image in the menu -->
                  
                  <!-- Menu Footer-->
                  <li class="user-footer">
                    <div class="pull-right">
                      <a href="./?view=processlogout" class="btn btn-default btn-flat">Salir</a>
                    </div>
                  </li>
                </ul>
              </li>
              <!-- Control Sidebar Toggle Button -->
            </ul>
          </div>
        </nav>
      </header>
      <!-- Left side column. contains the logo and sidebar -->
      <aside class="main-sidebar">

        <!-- sidebar: style can be found in sidebar.less -->
        <section class="sidebar">
          <!-- Sidebar Menu -->
          <ul class="sidebar-menu">
            <?php if(isset($_SESSION["user_id"])):?>
              <li><a href="./"><i class='fa fa-dashboard'></i> <span>Inicio</span></a></li>
              <li><a href="./?view=index"><i class='fa fa-dashboard'></i> <span>Ventas</span></a></li>
          <?php endif;?>

          </ul><!-- /.sidebar-menu -->
        </section>
        <!-- /.sidebar -->
      </aside>
    <?php endif;?>

      <!-- Content Wrapper. Contains page content -->
      <?php if(isset($_SESSION["user_id"])):?>
      <div class="content-wrapper">
        <?php View::load("index");?>
      </div><!-- /.content-wrapper -->

        <footer class="main-footer">
        <div class="pull-right hidden-xs">
          <b>Version</b> 1.0
        </div>
        <strong>Copyright &copy; 2021 <a href="" target="_blank">UCB</a></strong>
      </footer>
      <?php else:?>

<div class="login-box">
      <div class="login-logo">
      <?php 
  
  View::load("login");

?>
      </div><!-- /.login-box-body -->
    </div><!-- /.login-box -->  

      <?php endif;?>


    </div><!-- ./wrapper -->

    <!-- REQUIRED JS SCRIPTS -->

    <!-- jQuery 2.1.4 -->
    <!-- Bootstrap 3.3.2 JS -->
    <script src="librerias/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
    <!-- AdminLTE App -->
    <script src="librerias/dist/js/app.min.js" type="text/javascript"></script>

    
  </body>
</html>

