

<div class="login-box">
      <div class="login-logo">
        <a href="./">SISTEMA</a>
      </div><!-- /.login-logo -->
      <div class="login-box-body">
      <?php
        include_once("core/controller/Database.php");
      
    ?>
	  <form accept-charset="UTF-8" role="form" method="post" action="index.php?view=processlogin">
          <div class="form-group has-feedback">
            <input type="text" name="username" required class="form-control" placeholder="Usuario"/>
            <span class="glyphicon glyphicon-user form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
            <input type="password" name="password" required class="form-control" placeholder="Password"/>
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
          <div class="row">

            <div class="col-xs-12">
              <button type="submit" class="btn btn-primary btn-block btn-flat">Acceder</button>
            </div><!-- /.col -->
          </div>
        </form>
      </div><!-- /.login-box-body -->
    </div><!-- /.login-box --> 